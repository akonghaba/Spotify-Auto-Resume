
29/storage/emulated/0/CodeOnTheGoProjects/SpotifyAutoResume1794196256475"�
app/build.gradle.ktsN/storage/emulated/0/CodeOnTheGoProjects/SpotifyAutoResume/app/build.gradle.kts�) �Ү�4*@35934250ec1fbf0cc7111ab7924d41462f7329063020ddbfe3397e63f49a14ee"�
build.gradle.ktsJ/storage/emulated/0/CodeOnTheGoProjects/SpotifyAutoResume/build.gradle.kts� �Ӯ�4*@894c92aa66d7ae56d21573617b028f15675252935e41e9fd8165c4b41cec3d37"�
gradle.propertiesK/storage/emulated/0/CodeOnTheGoProjects/SpotifyAutoResume/gradle.properties�
 �Ӯ�4*@194f9064020d41d27decd9e74375ff1459b75854f0d68f38e0375ca3b4f031b4"�
(gradle/wrapper/gradle-wrapper.propertiesb/storage/emulated/0/CodeOnTheGoProjects/SpotifyAutoResume/gradle/wrapper/gradle-wrapper.properties� �Ӯ�4*@80dbd23007872ba453e1dcc698121d3c18d71e937a413f7543761a6d4ce93e40"�
settings.gradle.ktsM/storage/emulated/0/CodeOnTheGoProjects/SpotifyAutoResume/settings.gradle.kts� �Ӯ�4*@61f9c639add35fb1eac17352e6b4ccbca891bccb5bba6e2165b5ca1624dde762*�
T/storage/emulated/0/CodeOnTheGoProjects/SpotifyAutoResume/.cg/gradle-sync/project.pb@1082945cb911789b0e7049b7f0d1db1370cd5849a94277a4f9595608bea8c9ec